# Decisions log

Newest at the bottom. Add a line whenever something is decided, with the date and who decided. Scope decisions are Katy's; technical ones can be Claude's (say so).

## Oct 3, 2026: scope session (Katy)

- Build Social Studio as a private Boutiqly marketplace app: a tab in every sub-account, posting through Boutiqly's social planner. A human developer reviews security before paying clients connect.
- Always call the platform "Boutiqly" in the app, docs and conversation; never the vendor's name or abbreviation. Platform features get Boutiqly or plain names ("app ping").
- v1 makes everything the Make Space prototype makes, including full Reels, plus pins, Shorts, video titles and thumbnails, and Google updates.
- Channels: every channel Boutiqly's social planner posts to, plus ready-to-post packs for channels beyond it (X and others).
- Users: account owners, team members they designate, and Boutiqly's agency team; all can approve. Boutiqly's team sees everything on every brand for now (when to narrow it is left open).
- Onboarding starts with brand capture (website, linked socials, uploaded templates, loved posts, brand files) and a brand board the owner approves before anything else is made.
- A custom style set for every brand. All posts and Reels are on brand for their own sub-account; never Make Space branding anywhere else. Fallback: very basic Boutiqly palette and type, no logo.
- All Claude work in the app runs on Claude Opus 5.5 or newer. Ask Claude gets its full capabilities: strong design, no limit on what it can make.
- Assets: a people rule and a sensitive-details check (receipts, emails, phone numbers, addresses, customer names, payment details, customer-data screens, swear words, license plates) on every file.
- Screens: Calendar, Library, Assets, Ideas, Brand, plus Ask Claude on every screen. "Locked" becomes "Approved". Boutiqly look.
- Pricing: no monthly fee; Social Studio is part of every Boutiqly plan. Usage billed to the sub-account's wallet as Studio credits at 2x Claude cost. Each brand picks a monthly limit or unlimited. Done For You setup is part of white glove (always one price, includes everything in the plan).
- One brand per sub-account in v1. Name: Social Studio.
- Testing: Katy's brands first, then Bella and Brawn and Blue Bare, as soon as it's ready; Boutiqly covers the first round's credits.

## To decide in session 1 (Claude proposes, Katy OKs)

- Stack, repo layout, ORM and migrations, job queue, how the worker and web app share code.
